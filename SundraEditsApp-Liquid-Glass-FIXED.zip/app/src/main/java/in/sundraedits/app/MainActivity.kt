package in.sundraedits.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import org.json.JSONArray
import org.json.JSONObject

// Permanent SUNDRA EDITS brand palette from the supplied project.
private val Cream = Color(0xFFF5F1E8)
private val Ink = Color(0xFF252421)
private val Muted = Color(0xFF77736B)
private val Gold = Color(0xFFB69B66)
private val Panel = Color(0xFFFFFCF7)
private val DarkBg = Color(0xFF191918)
private val DarkPanel = Color(0xFF292722)
private val GoldLight = Color(0xFFD8C49A)

data class Invoice(val client: String, val description: String, val amount: Double, val currency: String, val paid: Double)
data class Expense(val title: String, val amount: Double)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(245, 241, 232)
        window.navigationBarColor = android.graphics.Color.rgb(245, 241, 232)
        setContent { SundraApp() }
    }
}

@Composable
fun SundraApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("sundra_local", 0) }
    var invoices by remember { mutableStateOf(loadInvoices(prefs)) }
    var expenses by remember { mutableStateOf(loadExpenses(prefs)) }
    var tab by remember { mutableStateOf("Overview") }
    var invoiceDialog by remember { mutableStateOf(false) }
    var expenseDialog by remember { mutableStateOf(false) }
    var dark by remember { mutableStateOf(false) }

    val bg = if (dark) DarkBg else Cream
    val panel = if (dark) DarkPanel else Panel
    val foreground = if (dark) Cream else Ink
    val secondary = if (dark) Color(0xFFB9B1A2) else Muted
    val collected = invoices.sumOf { it.paid }
    val outstanding = invoices.sumOf { (it.amount - it.paid).coerceAtLeast(0.0) }
    val totalExpenses = expenses.sumOf { it.amount }

    MaterialTheme(
        colorScheme = if (dark) darkColorScheme(primary = GoldLight, background = bg, surface = panel, onSurface = foreground)
        else lightColorScheme(primary = Gold, background = bg, surface = panel, onSurface = foreground)
    ) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(if (dark) Color(0xFF24221E) else Color(0xFFFFFCF7), bg, if (dark) DarkBg else Color(0xFFECE4D5))))) {
            // Soft ambient light pools behind translucent surfaces.
            Box(Modifier.align(Alignment.TopEnd).offset(x = 55.dp, y = 70.dp).size(190.dp).background((if (dark) Gold else GoldLight).copy(alpha = if (dark) .10f else .22f), CircleShape))
            Box(Modifier.align(Alignment.BottomStart).offset(x = (-70).dp, y = (-100).dp).size(190.dp).background(Gold.copy(alpha = .10f), CircleShape))

            Scaffold(
                containerColor = Color.Transparent,
                bottomBar = {
                    GlassNavigationBar(tab = tab, dark = dark, onSelect = { tab = it })
                }
            ) { scaffoldPadding ->
                Column(
                    Modifier.fillMaxSize()
                        .padding(scaffoldPadding)
                        .statusBarsPadding()
                        .padding(horizontal = 20.dp)
                        .verticalScroll(rememberScrollState())
                        .padding(bottom = 22.dp)
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 24.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("SUNDRA EDITS", color = foreground, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.4.sp)
                            Text("Your Vision. Our Creativity.", color = secondary, fontSize = 11.sp, letterSpacing = .5.sp)
                        }
                        GlassIconButton(if (dark) "☀" else "☾", dark) { dark = !dark }
                    }

                    when (tab) {
                        "Overview" -> {
                            Text("BUSINESS OVERVIEW", color = secondary, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                            Text("Your workspace", color = foreground, fontSize = 29.sp, fontWeight = FontWeight.Bold)
                            Text("A clear view of how your business is doing.", color = secondary, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp, bottom = 20.dp))
                            GlassCard(dark = dark, modifier = Modifier.fillMaxWidth(), accent = true) {
                                Column(Modifier.padding(20.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("TOTAL COLLECTED", color = secondary, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                                        Spacer(Modifier.weight(1f))
                                        GoldPill("LIVE SUMMARY", dark)
                                    }
                                    Text("₹ ${money(collected)}", color = foreground, fontSize = 32.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 9.dp))
                                    Text("Across recorded payments", color = secondary, fontSize = 12.sp)
                                    Spacer(Modifier.height(18.dp))
                                    Box(Modifier.fillMaxWidth().height(1.dp).background(Gold.copy(alpha = .28f)))
                                    Row(Modifier.fillMaxWidth().padding(top = 13.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Column { Text("INVOICES", color = secondary, fontSize = 9.sp, letterSpacing = 1.sp); Text(invoices.size.toString(), color = foreground, fontSize = 19.sp, fontWeight = FontWeight.SemiBold) }
                                        Column(horizontalAlignment = Alignment.End) { Text("OUTSTANDING", color = secondary, fontSize = 9.sp, letterSpacing = 1.sp); Text("₹ ${money(outstanding)}", color = foreground, fontSize = 19.sp, fontWeight = FontWeight.SemiBold) }
                                    }
                                }
                            }
                            Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                CompactMetric("EXPENSES", "₹ ${money(totalExpenses)}", "Recorded total", panel, foreground, secondary, dark, Modifier.weight(1f))
                                CompactMetric("PAYMENTS", invoices.count { it.paid > 0 }.toString(), "With payment", panel, foreground, secondary, dark, Modifier.weight(1f))
                            }
                            SectionHeading("Quick actions", "Manage your business")
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                ActionTile("＋", "New invoice", "Create a bill", dark, Modifier.weight(1f)) { invoiceDialog = true }
                                ActionTile("↗", "Add expense", "Track spending", dark, Modifier.weight(1f)) { expenseDialog = true }
                            }
                            SectionHeading("Recent invoices", "Your latest entries")
                            if (invoices.isEmpty()) EmptyGlassState("No invoices yet", "Create your first invoice to see it here.", dark)
                            else invoices.takeLast(3).reversed().forEach { InvoiceGlassRow(it, dark) }
                        }
                        "Invoices" -> {
                            ScreenTitle("Invoices", "Create and track client payments.", foreground, secondary)
                            GoldActionButton("＋  Create invoice", dark) { invoiceDialog = true }
                            Spacer(Modifier.height(16.dp))
                            if (invoices.isEmpty()) EmptyGlassState("No invoices recorded", "Your invoices will appear here.", dark)
                            else invoices.reversed().forEach { InvoiceGlassRow(it, dark) }
                        }
                        "Expenses" -> {
                            ScreenTitle("Expenses", "Keep your business spending organised.", foreground, secondary)
                            GlassCard(dark, Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(18.dp)) {
                                    Text("TOTAL RECORDED", color = secondary, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                                    Text("₹ ${money(totalExpenses)}", color = foreground, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            GoldActionButton("＋  Add expense", dark) { expenseDialog = true }
                            Spacer(Modifier.height(12.dp))
                            if (expenses.isEmpty()) EmptyGlassState("No expenses recorded", "Add business expenses to track them.", dark)
                            else expenses.reversed().forEach { ExpenseGlassRow(it, dark) }
                        }
                        else -> {
                            ScreenTitle("Settings", "Make your workspace feel right.", foreground, secondary)
                            GlassCard(dark, Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(19.dp)) {
                                    Text("SUNDRA EDITS", color = foreground, fontWeight = FontWeight.Bold, letterSpacing = 1.8.sp)
                                    Text("Your Vision. Our Creativity.", color = secondary, fontSize = 12.sp)
                                    Spacer(Modifier.height(15.dp))
                                    SettingLine("Brand palette", "Cream · Champagne Gold", dark)
                                    SettingLine("Currency labels", "INR ₹ / USD $", dark)
                                    SettingLine("Data storage", "Offline on this device", dark)
                                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp)) {
                                        Column(Modifier.weight(1f)) { Text("Dark appearance", color = foreground, fontWeight = FontWeight.SemiBold); Text("Keep the glass look at night", color = secondary, fontSize = 11.sp) }
                                        Switch(checked = dark, onCheckedChange = { dark = it }, colors = SwitchDefaults.colors(checkedThumbColor = Ink, checkedTrackColor = Gold))
                                    }
                                }
                            }
                            Spacer(Modifier.height(14.dp))
                            Text("Your records are stored locally on this device. Cloud sync and backup are not included in this starter build.", color = secondary, fontSize = 11.sp, lineHeight = 16.sp)
                        }
                    }
                }
            }
        }

        if (invoiceDialog) InvoiceGlassDialog(dark, onDismiss = { invoiceDialog = false }) { inv ->
            invoices = invoices + inv
            saveInvoices(prefs, invoices)
            invoiceDialog = false
        }
        if (expenseDialog) ExpenseGlassDialog(dark, onDismiss = { expenseDialog = false }) { expense ->
            expenses = expenses + expense
            saveExpenses(prefs, expenses)
            expenseDialog = false
        }
    }
}

@Composable
private fun GlassCard(dark: Boolean, modifier: Modifier = Modifier, accent: Boolean = false, content: @Composable ColumnScope.() -> Unit) {
    val fill = if (dark) Color(0xFF343129).copy(alpha = .78f) else Color.White.copy(alpha = if (accent) .68f else .57f)
    val outline = if (dark) Color.White.copy(alpha = .13f) else Color.White.copy(alpha = .88f)
    Column(
        modifier.shadow(if (accent) 14.dp else 8.dp, RoundedCornerShape(26.dp), ambientColor = Gold.copy(alpha = .12f), spotColor = Gold.copy(alpha = .10f))
            .clip(RoundedCornerShape(26.dp))
            .background(if (accent) Brush.linearGradient(listOf(fill, if (dark) Gold.copy(alpha = .13f) else Gold.copy(alpha = .12f))) else Brush.linearGradient(listOf(fill, fill.copy(alpha = .78f))))
            .border(BorderStroke(1.dp, Brush.linearGradient(listOf(outline, Gold.copy(alpha = .28f), outline.copy(alpha = .35f)))), RoundedCornerShape(26.dp))
    ) { content() }
}

@Composable
private fun GlassNavigationBar(tab: String, dark: Boolean, onSelect: (String) -> Unit) {
    val tabs = listOf("Overview" to "⌂", "Invoices" to "▤", "Expenses" to "↗", "Settings" to "⚙")
    Box(Modifier.fillMaxWidth().navigationBarsPadding().padding(start = 16.dp, end = 16.dp, bottom = 10.dp, top = 5.dp)) {
        Row(
            Modifier.fillMaxWidth().shadow(16.dp, RoundedCornerShape(28.dp)).clip(RoundedCornerShape(28.dp))
                .background(if (dark) Color(0xFF343129).copy(alpha = .94f) else Color.White.copy(alpha = .82f))
                .border(1.dp, if (dark) Color.White.copy(alpha = .13f) else Color.White.copy(alpha = .95f), RoundedCornerShape(28.dp))
                .padding(horizontal = 7.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            tabs.forEach { (label, symbol) ->
                val selected = tab == label
                Column(
                    Modifier.weight(1f).clip(RoundedCornerShape(20.dp)).clickable { onSelect(label) }
                        .background(if (selected) Gold.copy(alpha = if (dark) .25f else .19f) else Color.Transparent)
                        .padding(vertical = 7.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(symbol, color = if (selected) Gold else if (dark) Cream.copy(alpha = .72f) else Muted, fontSize = 20.sp)
                    Text(label, color = if (selected) (if (dark) GoldLight else Ink) else if (dark) Cream.copy(alpha = .70f) else Muted, fontSize = 9.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium)
                }
            }
        }
    }
}

@Composable private fun GlassIconButton(label: String, dark: Boolean, onClick: () -> Unit) {
    Box(Modifier.size(43.dp).shadow(7.dp, CircleShape).clip(CircleShape).background(if (dark) Color.White.copy(alpha = .10f) else Color.White.copy(alpha = .72f)).border(1.dp, if (dark) Color.White.copy(alpha = .16f) else Color.White, CircleShape).clickable { onClick() }, contentAlignment = Alignment.Center) {
        Text(label, color = if (dark) Cream else Ink, fontSize = 21.sp)
    }
}

@Composable private fun GoldPill(text: String, dark: Boolean) {
    Box(Modifier.clip(CircleShape).background(Gold.copy(alpha = if (dark) .22f else .17f)).padding(horizontal = 10.dp, vertical = 5.dp)) {
        Text(text, color = if (dark) GoldLight else Gold, fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = .8.sp)
    }
}

@Composable private fun CompactMetric(title: String, value: String, note: String, panel: Color, foreground: Color, secondary: Color, dark: Boolean, modifier: Modifier) {
    GlassCard(dark, modifier) {
        Column(Modifier.padding(15.dp)) {
            Text(title, color = secondary, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
            Text(value, color = foreground, fontSize = 19.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 7.dp))
            Text(note, color = secondary, fontSize = 10.sp)
        }
    }
}

@Composable private fun SectionHeading(title: String, subtitle: String) {
    Column(Modifier.padding(top = 23.dp, bottom = 11.dp)) {
        Text(title, color = Ink, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, color = Muted, fontSize = 11.sp)
    }
}

@Composable private fun ActionTile(symbol: String, title: String, subtitle: String, dark: Boolean, modifier: Modifier, onClick: () -> Unit) {
    GlassCard(dark, modifier.clickable { onClick() }) {
        Column(Modifier.padding(15.dp)) {
            Box(Modifier.size(34.dp).clip(CircleShape).background(Gold.copy(alpha = .19f)), contentAlignment = Alignment.Center) { Text(symbol, color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
            Text(title, color = if (dark) Cream else Ink, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp))
            Text(subtitle, color = if (dark) Color.LightGray else Muted, fontSize = 10.sp)
        }
    }
}

@Composable private fun ScreenTitle(title: String, subtitle: String, foreground: Color, secondary: Color) {
    Text(title, color = foreground, fontSize = 28.sp, fontWeight = FontWeight.Bold)
    Text(subtitle, color = secondary, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp, bottom = 18.dp))
}

@Composable private fun GoldActionButton(label: String, dark: Boolean, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = Modifier.fillMaxWidth().padding(top = 8.dp).height(52.dp), shape = RoundedCornerShape(18.dp), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink), elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp)) {
        Text(label, fontWeight = FontWeight.Bold)
    }
}

@Composable private fun InvoiceGlassRow(inv: Invoice, dark: Boolean) {
    val foreground = if (dark) Cream else Ink
    val secondary = if (dark) Color.LightGray else Muted
    val due = (inv.amount - inv.paid).coerceAtLeast(0.0)
    GlassCard(dark, Modifier.fillMaxWidth().padding(bottom = 9.dp)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(inv.client, color = foreground, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Text(inv.description.ifBlank { "Service / invoice" }, color = secondary, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(if (due <= 0.0) "PAID" else "DUE ${inv.currency} ${money(due)}", color = if (due <= 0.0) Gold else secondary, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 5.dp))
            }
            Spacer(Modifier.width(8.dp))
            Text("${inv.currency} ${money(inv.amount)}", color = foreground, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
    }
}

@Composable private fun ExpenseGlassRow(expense: Expense, dark: Boolean) {
    GlassCard(dark, Modifier.fillMaxWidth().padding(bottom = 9.dp)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(expense.title, color = if (dark) Cream else Ink, fontWeight = FontWeight.SemiBold)
            Text("₹ ${money(expense.amount)}", color = if (dark) Cream else Ink, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable private fun EmptyGlassState(title: String, subtitle: String, dark: Boolean) {
    GlassCard(dark, Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth().padding(25.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("✧", color = Gold, fontSize = 27.sp)
            Text(title, color = if (dark) Cream else Ink, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = if (dark) Color.LightGray else Muted, fontSize = 11.sp)
        }
    }
}

@Composable private fun SettingLine(title: String, value: String, dark: Boolean) {
    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Text(title, color = if (dark) Cream else Ink, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
        Text(value, color = if (dark) Color.LightGray else Muted, fontSize = 11.sp)
    }
}

@Composable private fun InvoiceGlassDialog(dark: Boolean, onDismiss: () -> Unit, onSave: (Invoice) -> Unit) {
    var client by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var currency by remember { mutableStateOf("₹") }
    var paid by remember { mutableStateOf("0") }
    GlassDialogFrame(dark, onDismiss, "Create invoice", "Add the client and payment details.") {
        GlassInput(client, { client = it }, "Client name", dark)
        GlassInput(description, { description = it }, "Service / description", dark)
        GlassInput(amount, { amount = it }, "Invoice amount", dark)
        GlassInput(paid, { paid = it }, "Paid amount", dark)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("₹" to "INR ₹", "$" to "USD $").forEach { (symbol, label) ->
                FilterChip(selected = currency == symbol, onClick = { currency = symbol }, label = { Text(label) }, colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Gold.copy(alpha = .25f)))
            }
        }
        val a = amount.toDoubleOrNull()
        val p = paid.toDoubleOrNull()
        DialogActions(dark, onDismiss, enabled = client.isNotBlank() && a != null && a >= 0 && p != null && p >= 0 && p <= a) {
            onSave(Invoice(client.trim(), description.trim(), a!!, currency, p!!))
        }
    }
}

@Composable private fun ExpenseGlassDialog(dark: Boolean, onDismiss: () -> Unit, onSave: (Expense) -> Unit) {
    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    GlassDialogFrame(dark, onDismiss, "Add expense", "Record a business expense.") {
        GlassInput(title, { title = it }, "Expense name", dark)
        GlassInput(amount, { amount = it }, "Amount", dark)
        val value = amount.toDoubleOrNull()
        DialogActions(dark, onDismiss, enabled = title.isNotBlank() && value != null && value >= 0) {
            onSave(Expense(title.trim(), value!!))
        }
    }
}

@Composable private fun GlassDialogFrame(dark: Boolean, onDismiss: () -> Unit, title: String, subtitle: String, content: @Composable ColumnScope.() -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(if (dark) Color(0xFF343129) else Color(0xFFFDFBF6)).border(1.dp, Gold.copy(alpha = .38f), RoundedCornerShape(28.dp)).padding(20.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
            Text(title, color = if (dark) Cream else Ink, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = if (dark) Color.LightGray else Muted, fontSize = 11.sp)
            content()
        }
    }
}

@Composable private fun GlassInput(value: String, onValueChange: (String) -> Unit, label: String, dark: Boolean) {
    OutlinedTextField(value, onValueChange, modifier = Modifier.fillMaxWidth(), label = { Text(label) }, singleLine = true, shape = RoundedCornerShape(15.dp), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Gold, unfocusedBorderColor = Gold.copy(alpha = .35f), focusedLabelColor = Gold, unfocusedLabelColor = if (dark) Color.LightGray else Muted, focusedTextColor = if (dark) Cream else Ink, unfocusedTextColor = if (dark) Cream else Ink, cursorColor = Gold))
}

@Composable private fun DialogActions(dark: Boolean, onDismiss: () -> Unit, enabled: Boolean, onSave: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
        TextButton(onClick = onDismiss) { Text("Cancel", color = if (dark) Cream else Muted) }
        Button(onClick = onSave, enabled = enabled, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink), shape = RoundedCornerShape(13.dp)) { Text("Save", fontWeight = FontWeight.Bold) }
    }
}

private fun money(value: Double): String = String.format(java.util.Locale.US, "%,.2f", value)

private fun loadInvoices(p: android.content.SharedPreferences): List<Invoice> = try {
    val array = JSONArray(p.getString("invoices", "[]"))
    (0 until array.length()).map { index ->
        val obj = array.getJSONObject(index)
        Invoice(obj.optString("client"), obj.optString("desc"), obj.optDouble("amount"), obj.optString("currency", "₹"), obj.optDouble("paid"))
    }
} catch (_: Exception) { emptyList() }

private fun saveInvoices(p: android.content.SharedPreferences, list: List<Invoice>) {
    val array = JSONArray()
    list.forEach { array.put(JSONObject().put("client", it.client).put("desc", it.description).put("amount", it.amount).put("currency", it.currency).put("paid", it.paid)) }
    p.edit().putString("invoices", array.toString()).apply()
}

private fun loadExpenses(p: android.content.SharedPreferences): List<Expense> = try {
    val array = JSONArray(p.getString("expenses", "[]"))
    (0 until array.length()).map { index -> val obj = array.getJSONObject(index); Expense(obj.optString("title"), obj.optDouble("amount")) }
} catch (_: Exception) { emptyList() }

private fun saveExpenses(p: android.content.SharedPreferences, list: List<Expense>) {
    val array = JSONArray()
    list.forEach { array.put(JSONObject().put("title", it.title).put("amount", it.amount)) }
    p.edit().putString("expenses", array.toString()).apply()
}
