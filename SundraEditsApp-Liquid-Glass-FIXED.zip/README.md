# SUNDRA EDITS Android App - Premium Liquid Glass Edition

A native Kotlin + Jetpack Compose Android project with offline local persistence for invoice entries and expenses.

## Current implemented MVP
- Dashboard totals for collected revenue, outstanding amount, invoice count, and expenses
- Add and list invoice entries (client, description, amount, currency, paid amount)
- Add and list expenses
- INR and USD entry labels
- Permanent Cream + Champagne Gold brand palette
- Premium Liquid Glass-inspired translucent cards, gradient highlights, floating navigation, and glass-style dialogs
- Light/dark toggle
- Local persistence with SharedPreferences (records survive app restarts)

## Build APK
1. Upload the entire project folder to a GitHub repository, keeping the root files and `app/` folder intact.
2. Confirm the workflow file exists at `.github/workflows/build-apk.yml`.
3. Open the repository's **Actions** tab.
4. Select **Build SUNDRA EDITS APK** and press **Run workflow** (or push to `main`/`master`).
5. When complete, open the successful workflow run and download the `SundraEdits-debug-apk` artifact.
6. Extract the artifact ZIP and install the APK on Android. Android may ask to allow installation from that source.

## Build locally
Requires Android SDK and JDK 17. From the project root run:

`gradle assembleDebug`

APK output: `app/build/outputs/apk/debug/app-debug.apk`

## Limitations
This starter is not yet the full business suite. PDF invoice generation, native WhatsApp attachment sharing, quotations, detailed payment ledger, GST, backup/restore, analytics filters, and client/service catalog are not implemented yet.
