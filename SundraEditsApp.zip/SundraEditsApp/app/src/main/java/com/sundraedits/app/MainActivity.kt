package com.sundraedits.app

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sundraedits.app.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Gold = Color(0xFFB8975A)
private val Green = Color(0xFF4F8A5B)
private val Amber = Color(0xFFB5651D)
private val CATS = listOf("Video Editing", "Social Media Management", "Website Development")

class MainActivity : ComponentActivity() {
    private val vm: VM by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val dark = isSystemInDarkTheme()
            val ink = if (dark) Color(0xFFEDE8DC) else Color(0xFF2B2B2B)
            MaterialTheme(colorScheme = if (dark) darkColorScheme(primary = Gold) else lightColorScheme(primary = Gold)) {
                CompositionLocalProvider(LocalContentColor provides ink) {
                    GlassBg { App(vm) }
                }
            }
        }
    }
}

/* ---------- Liquid glass design ---------- */

@Composable
private fun GlassBg(content: @Composable BoxScope.() -> Unit) {
    val dark = isSystemInDarkTheme()
    val t by rememberInfiniteTransition(label = "bg").animateFloat(
        0f, 1f, infiniteRepeatable(tween(16000, easing = LinearEasing), RepeatMode.Reverse), label = "t")
    Box(
        Modifier.fillMaxSize()
            .background(if (dark) Color(0xFF14130F) else Color(0xFFF6EFE2))
            .drawBehind {
                val r = size.width * 0.75f
                val a = Offset(size.width * (0.1f + 0.6f * t), size.height * 0.15f)
                val b = Offset(size.width * (0.9f - 0.6f * t), size.height * 0.75f)
                drawCircle(Brush.radialGradient(listOf(Gold.copy(alpha = if (dark) 0.28f else 0.45f), Color.Transparent), a, r), r, a)
                drawCircle(Brush.radialGradient(listOf(Color(0xFFE9D9B8).copy(alpha = if (dark) 0.15f else 0.7f), Color.Transparent), b, r), r, b)
            },
        content = content
    )
}

@Composable
private fun Glass(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val dark = isSystemInDarkTheme()
    val shape = RoundedCornerShape(22.dp)
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pressed) 0.97f else 1f, spring(dampingRatio = 0.6f), label = "press")
    var m = modifier.graphicsLayer { scaleX = sc; scaleY = sc }
        .clip(shape)
        .background(Brush.verticalGradient(listOf(
            Color.White.copy(alpha = if (dark) 0.14f else 0.72f),
            Color.White.copy(alpha = if (dark) 0.05f else 0.38f))))
        .border(1.dp, Brush.verticalGradient(listOf(
            Color.White.copy(alpha = if (dark) 0.40f else 0.95f), Gold.copy(alpha = 0.25f))), shape)
    if (onClick != null) m = m.clickable(interactionSource = src, indication = null, onClick = onClick)
    Column(m.padding(16.dp), content = content)
}

@Composable
private fun Pill(paid: Boolean) {
    val col = if (paid) Green else Amber
    Box(Modifier.clip(RoundedCornerShape(50)).background(col.copy(alpha = 0.18f)).padding(horizontal = 10.dp, vertical = 3.dp)) {
        Text(if (paid) "PAID" else "DUE", color = col, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun GoldButton(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    Button(onClick = onClick, enabled = enabled, modifier = Modifier.fillMaxWidth(),
        colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color.White)) { Text(text) }
}

/* ---------- App shell ---------- */

@Composable
private fun App(vm: VM) {
    var tab by remember { mutableStateOf("home") }
    var detail by remember { mutableStateOf<Long?>(null) }
    BackHandler(enabled = detail != null || tab != "home") { if (detail != null) detail = null else tab = "home" }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Box(Modifier.weight(1f)) {
            Crossfade(targetState = (detail?.toString() ?: tab), animationSpec = tween(260), label = "screen") { _ ->
                val d = detail
                when {
                    d != null -> Detail(vm, d) { detail = null }
                    tab == "home" -> Home(vm) { detail = it }
                    tab == "clients" -> Clients(vm)
                    tab == "new" -> NewInvoice(vm) { id -> detail = id; tab = "home" }
                    else -> SettingsScreen(vm)
                }
            }
        }
        Glass(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp).navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                listOf("home" to "Invoices", "clients" to "Clients", "new" to "+ New", "settings" to "Settings").forEach { (k, label) ->
                    val sel = tab == k && detail == null
                    Text(label, color = if (sel) Gold else LocalContentColor.current.copy(alpha = 0.6f),
                        fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.clickable { tab = k; detail = null }.padding(8.dp))
                }
            }
        }
    }
}

@Composable
private fun Stat(label: String, value: String, modifier: Modifier) {
    Glass(modifier) {
        Text(label, fontSize = 12.sp, color = LocalContentColor.current.copy(alpha = 0.65f))
        Text(value, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
    }
}

/* ---------- Home ---------- */

@Composable
private fun Home(vm: VM, open: (Long) -> Unit) {
    val rows by vm.rows.collectAsStateWithLifecycle()
    val got = rows.filter { it.inv.paid }.sumOf { it.total }
    val due = rows.filter { !it.inv.paid }.sumOf { it.total }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("SUNDRA EDITS", fontSize = 26.sp, fontWeight = FontWeight.SemiBold)
            Text("Your Vision. Our Creativity.", color = Gold, fontSize = 12.sp)
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Stat("Received", money(got), Modifier.weight(1f))
                Stat("Due", money(due), Modifier.weight(1f))
            }
        }
        if (rows.isEmpty()) item { Text("No invoices yet. Add a client, then tap + New.") }
        items(rows, key = { it.inv.id }) { r ->
            Glass(Modifier.fillMaxWidth(), onClick = { open(r.inv.id) }) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(r.inv.number, fontWeight = FontWeight.SemiBold)
                        Text(r.inv.clientName, fontSize = 13.sp)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(money(r.total), fontWeight = FontWeight.Medium)
                        Pill(r.inv.paid)
                    }
                }
            }
        }
    }
}

/* ---------- Clients ---------- */

@Composable
private fun Clients(vm: VM) {
    val clients by vm.clients.collectAsStateWithLifecycle()
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Glass(Modifier.fillMaxWidth()) {
                Text("New client", fontWeight = FontWeight.SemiBold)
                OutlinedTextField(name, { name = it }, label = { Text("Client name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(phone, { phone = it }, label = { Text("Phone / WhatsApp") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.fillMaxWidth())
                OutlinedTextField(email, { email = it }, label = { Text("Email") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email), modifier = Modifier.fillMaxWidth())
                if (err.isNotEmpty()) Text(err, color = Amber, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                GoldButton("Add client") {
                    if (name.isBlank()) err = "Enter the client name" else {
                        vm.addClient(name, phone, email); name = ""; phone = ""; email = ""; err = ""
                    }
                }
            }
        }
        items(clients, key = { it.id }) { c ->
            Glass(Modifier.fillMaxWidth()) {
                Text(c.name, fontWeight = FontWeight.SemiBold)
                if (c.phone.isNotBlank()) Text(c.phone, fontSize = 13.sp)
                if (c.email.isNotBlank()) Text(c.email, fontSize = 13.sp)
            }
        }
    }
}

/* ---------- New invoice ---------- */

private data class Draft(val cat: String = CATS[0], val desc: String = "", val qty: String = "1", val rate: String = "")

private fun toMinor(s: String): Long? =
    s.trim().toBigDecimalOrNull()?.multiply(BigDecimal(100))?.setScale(0, RoundingMode.HALF_UP)?.toLong()

@Composable
private fun NewInvoice(vm: VM, done: (Long) -> Unit) {
    val clients by vm.clients.collectAsStateWithLifecycle()
    var cid by remember { mutableStateOf<Long?>(null) }
    val drafts = remember { mutableStateListOf(Draft()) }
    var paid by remember { mutableStateOf(true) }
    var notes by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    var saving by remember { mutableStateOf(false) }
    val total = drafts.sumOf { (it.qty.toIntOrNull() ?: 0) * (toMinor(it.rate) ?: 0L) }

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Glass(Modifier.fillMaxWidth()) {
                Text("Client", fontWeight = FontWeight.SemiBold)
                if (clients.isEmpty()) Text("Add a client first (Clients tab).", color = Amber)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    clients.forEach { c ->
                        FilterChip(selected = cid == c.id, onClick = { cid = c.id }, label = { Text(c.name) })
                    }
                }
            }
        }
        items(drafts.size) { idx ->
            val d = drafts[idx]
            Glass(Modifier.fillMaxWidth()) {
                Text("Service ${idx + 1}", fontWeight = FontWeight.SemiBold)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CATS.forEach { k -> FilterChip(selected = d.cat == k, onClick = { drafts[idx] = d.copy(cat = k) }, label = { Text(k) }) }
                }
                OutlinedTextField(d.desc, { drafts[idx] = d.copy(desc = it) }, label = { Text("What work was done") }, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(d.qty, { drafts[idx] = d.copy(qty = it) }, label = { Text("Qty") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f))
                    OutlinedTextField(d.rate, { drafts[idx] = d.copy(rate = it) }, label = { Text("Price ₹") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f))
                }
                if (drafts.size > 1) TextButton(onClick = { drafts.removeAt(idx) }) { Text("Remove this service", color = Amber) }
            }
        }
        item { OutlinedButton(onClick = { drafts.add(Draft()) }, modifier = Modifier.fillMaxWidth()) { Text("+ Add another service") } }
        item {
            Glass(Modifier.fillMaxWidth()) {
                OutlinedTextField(notes, { notes = it }, label = { Text("Notes (optional)") }, modifier = Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Payment received (Paid)", Modifier.weight(1f))
                    Switch(checked = paid, onCheckedChange = { paid = it })
                }
                Text("Total: " + money(total), fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                if (err.isNotEmpty()) Text(err, color = Amber, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                GoldButton("Save invoice", enabled = !saving) {
                    val items = drafts.mapNotNull { d ->
                        val q = d.qty.toIntOrNull(); val r = toMinor(d.rate)
                        if (d.desc.isBlank() || q == null || q <= 0 || r == null || r <= 0) null
                        else Item(invoiceId = 0, category = d.cat, description = d.desc.trim(), qty = q, rateMinor = r)
                    }
                    val c = cid
                    if (c == null) err = "Select a client"
                    else if (items.size != drafts.size) err = "Fill work done, quantity and price for every service"
                    else { saving = true; err = ""; vm.save(c, items, paid, notes, done) }
                }
            }
        }
    }
}

/* ---------- Detail + sharing ---------- */

private fun shareInvoice(ctx: Context, inv: Invoice, items: List<Item>, p: Prefs, total: Long, whatsapp: Boolean) {
    try {
        val f = PdfMaker.make(ctx, inv, items, p)
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
        val who = inv.clientName.trim()
        val greet = if (who.isEmpty()) "Dear Sir/Madam," else "Dear Sir/Madam $who,"
        val line = if (inv.paid) "Please find attached your invoice ${inv.number} for ${money(total)} (Paid)."
        else "Please find attached your invoice ${inv.number}. Amount due: ${money(total)}."
        val msg = "$greet\n\n$line\n\nKindly review the invoice and let us know if you have any questions.\n\n" +
            "Thank you for choosing ${p.get("name")}.\n\nYour Vision. Our Creativity."
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri); putExtra(Intent.EXTRA_TEXT, msg)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        if (whatsapp) {
            for (pkg in listOf("com.whatsapp", "com.whatsapp.w4b")) {
                try { ctx.startActivity(Intent(i).setPackage(pkg)); return } catch (_: ActivityNotFoundException) {}
            }
            Toast.makeText(ctx, "WhatsApp not found. Choose another app.", Toast.LENGTH_LONG).show()
        }
        ctx.startActivity(Intent.createChooser(i, "Share invoice"))
    } catch (e: Exception) {
        Toast.makeText(ctx, "Could not create PDF: ${e.message}", Toast.LENGTH_LONG).show()
    }
}

@Composable
private fun Detail(vm: VM, id: Long, back: () -> Unit) {
    val ctx = LocalContext.current
    val rows by vm.rows.collectAsStateWithLifecycle()
    val r = rows.firstOrNull { it.inv.id == id }
    var lines by remember { mutableStateOf(emptyList<Item>()) }
    LaunchedEffect(id) { lines = vm.dao.itemsOf(id) }
    val df = remember { SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH) }
    if (r == null) { Box(Modifier.fillMaxSize(), Alignment.Center) { Text("Loading…") }; return }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Glass(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(r.inv.number, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                    Text(r.inv.clientName)
                    Text(df.format(Date(r.inv.date)), fontSize = 12.sp)
                }
                Pill(r.inv.paid)
            }
        }
        lines.forEach { l ->
            Glass(Modifier.fillMaxWidth()) {
                Text(l.category, color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text(l.description)
                Text("${l.qty} × ${money(l.rateMinor)} = ${money(l.qty * l.rateMinor)}", fontSize = 13.sp)
            }
        }
        Glass(Modifier.fillMaxWidth()) { Text("Total: " + money(r.total), fontSize = 22.sp, fontWeight = FontWeight.SemiBold) }
        GoldButton("Share on WhatsApp") { shareInvoice(ctx, r.inv, lines, vm.prefs, r.total, true) }
        OutlinedButton(onClick = { shareInvoice(ctx, r.inv, lines, vm.prefs, r.total, false) }, modifier = Modifier.fillMaxWidth()) { Text("Share PDF with another app") }
        OutlinedButton(onClick = { vm.setPaid(r.inv.id, !r.inv.paid) }, modifier = Modifier.fillMaxWidth()) {
            Text(if (r.inv.paid) "Mark as Due" else "Mark as Paid")
        }
        TextButton(onClick = back, modifier = Modifier.fillMaxWidth()) { Text("Back") }
    }
}

/* ---------- Settings + backup ---------- */

@Composable
private fun SettingsScreen(vm: VM) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val keys = listOf("name" to "Business name", "phone" to "Phone", "email" to "Email", "website" to "Website",
        "upi" to "UPI ID", "bank" to "Bank details (shown on unpaid invoices)", "terms" to "Terms on invoice")
    val vals = remember { mutableStateMapOf<String, String>().apply { keys.forEach { put(it.first, vm.prefs.get(it.first)) } } }
    var msg by remember { mutableStateOf("") }
    var pending by remember { mutableStateOf<Backup.Parsed?>(null) }

    val exp = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch {
            try {
                val s = Backup.export(vm.dao, vm.prefs)
                withContext(Dispatchers.IO) { ctx.contentResolver.openOutputStream(uri)!!.use { it.write(s.toByteArray()) } }
                msg = "Backup saved."
            } catch (e: Exception) { msg = "Backup failed: ${e.message}" }
        }
    }
    val imp = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            try {
                val s = withContext(Dispatchers.IO) { ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes().toString(Charsets.UTF_8) } }
                pending = Backup.parse(s)
            } catch (e: Exception) { msg = "Invalid backup file: ${e.message}. Nothing was changed." }
        }
    }

    pending?.let { p ->
        AlertDialog(
            onDismissRequest = { pending = null },
            title = { Text("Restore backup?") },
            text = { Text("This replaces ALL current data with the backup (${p.clients.size} clients, ${p.invoices.size} invoices).") },
            confirmButton = {
                TextButton(onClick = {
                    pending = null
                    scope.launch {
                        try {
                            Backup.restore(vm.db, vm.prefs, p)
                            keys.forEach { vals[it.first] = vm.prefs.get(it.first) }
                            msg = "Backup restored."
                        } catch (e: Exception) { msg = "Restore failed: ${e.message}" }
                    }
                }) { Text("Restore") }
            },
            dismissButton = { TextButton(onClick = { pending = null }) { Text("Cancel") } }
        )
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Glass(Modifier.fillMaxWidth()) {
            Text("Business details", fontWeight = FontWeight.SemiBold)
            keys.forEach { (k, label) ->
                OutlinedTextField(vals[k] ?: "", { vals[k] = it }, label = { Text(label) }, modifier = Modifier.fillMaxWidth())
            }
            Spacer(Modifier.height(8.dp))
            GoldButton("Save settings") { keys.forEach { vm.prefs.set(it.first, vals[it.first] ?: "") }; msg = "Settings saved." }
        }
        Glass(Modifier.fillMaxWidth()) {
            Text("Backup", fontWeight = FontWeight.SemiBold)
            Text("Saves clients, invoices and settings to a file you choose.", fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            GoldButton("Export backup") {
                exp.launch("SundraEdits_backup_" + SimpleDateFormat("yyyyMMdd", Locale.ENGLISH).format(Date()) + ".json")
            }
            OutlinedButton(onClick = { imp.launch(arrayOf("application/json", "text/plain", "application/octet-stream")) },
                modifier = Modifier.fillMaxWidth()) { Text("Restore backup") }
        }
        if (msg.isNotEmpty()) Text(msg, color = Gold)
    }
}
