package com.sundraedits.app

import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfDocument
import com.sundraedits.app.data.*
import java.io.File
import java.io.FileOutputStream
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

fun money(minor: Long): String {
    val nf = NumberFormat.getNumberInstance(Locale("en", "IN"))
    nf.minimumFractionDigits = 2; nf.maximumFractionDigits = 2
    return "₹" + nf.format(minor / 100.0)
}

object PdfMaker {
    private val CREAM = 0xFFFAF4E8.toInt()
    private val INK = 0xFF2B2B2B.toInt()
    private val GOLD = 0xFFB8975A.toInt()
    private val MUTED = 0xFF7A7467.toInt()
    private val GREEN = 0xFF4F8A5B.toInt()
    private val AMBER = 0xFFB5651D.toInt()

    private fun pt(size: Float, color: Int, bold: Boolean = false, align: Paint.Align = Paint.Align.LEFT) =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size; this.color = color; textAlign = align
            typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }

    /** Wraps text to a width and breaks very long words, so nothing overflows. */
    fun wrap(t: String, p: Paint, w: Float): List<String> {
        val out = mutableListOf<String>()
        for (para in t.split("\n")) {
            var line = ""
            for (word in para.split(" ")) {
                var wd = word
                while (p.measureText(wd) > w) {
                    val n = p.breakText(wd, true, w, null).coerceAtLeast(1)
                    if (line.isNotEmpty()) { out.add(line); line = "" }
                    out.add(wd.substring(0, n)); wd = wd.substring(n)
                }
                val cand = if (line.isEmpty()) wd else "$line $wd"
                if (p.measureText(cand) <= w) line = cand else { out.add(line); line = wd }
            }
            out.add(line)
        }
        return out
    }

    fun fileName(client: String, number: String): String {
        val c = client.replace(Regex("[^\\p{L}\\p{N}]+"), "_").trim('_').ifEmpty { "Client" }
        return c + "_" + number + ".pdf"
    }

    fun make(ctx: Context, inv: Invoice, items: List<Item>, p: Prefs): File {
        val doc = PdfDocument()
        val df = SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH)
        val L = 40f; val R = 555f; val LIMIT = 700f
        var pageNo = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNo).create())
        var c = page.canvas
        c.drawColor(CREAM)

        fun compact() {
            c.drawText("${p.get("name")}  •  ${p.get("phone")}  •  Page $pageNo", 297.5f, 820f,
                pt(8f, MUTED, align = Paint.Align.CENTER))
        }
        fun newPage(): Float {
            compact(); doc.finishPage(page); pageNo++
            page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNo).create())
            c = page.canvas; c.drawColor(CREAM); return 48f
        }
        val line = Paint().apply { color = 0x33B8975A; strokeWidth = 0.8f }

        // Header
        val logoId = ctx.resources.getIdentifier("logo", "drawable", ctx.packageName)
        val bmp = BitmapFactory.decodeResource(ctx.resources, logoId,
            BitmapFactory.Options().apply { inSampleSize = 2 })
        if (bmp != null) c.drawBitmap(bmp, null, RectF(L, 34f, L + 84f, 118f), Paint(Paint.FILTER_BITMAP_FLAG))
        c.drawText(p.get("name"), 138f, 68f, pt(18f, INK, true))
        c.drawText("Your Vision. Our Creativity.", 138f, 86f, pt(9.5f, GOLD))
        c.drawText(p.get("website"), 138f, 101f, pt(9.5f, MUTED))
        c.drawText("INVOICE", R, 62f, pt(24f, GOLD, true, Paint.Align.RIGHT))
        c.drawText(inv.number, R, 82f, pt(12f, INK, true, Paint.Align.RIGHT))
        c.drawText("Date: " + df.format(Date(inv.date)), R, 98f, pt(10f, MUTED, align = Paint.Align.RIGHT))
        c.drawLine(L, 136f, R, 136f, line)

        // Billed to + status stamp
        c.drawText("BILLED TO", L, 162f, pt(8.5f, GOLD, true))
        var y = 180f
        val nameLines = wrap(inv.clientName.ifBlank { "Valued Client" }, pt(13f, INK, true), 330f)
        nameLines.forEach { c.drawText(it, L, y, pt(13f, INK, true)); y += 16f }
        val stamp = if (inv.paid) "PAID" else "DUE"
        val sc = if (inv.paid) GREEN else AMBER
        val box = RectF(R - 100f, 148f, R, 180f)
        c.drawRoundRect(box, 8f, 8f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = 1.5f; color = sc })
        c.drawText(stamp, box.centerX(), 170f, pt(15f, sc, true, Paint.Align.CENTER))
        if (inv.paid && inv.paidDate != null)
            c.drawText("on " + df.format(Date(inv.paidDate)), R, 195f, pt(9f, MUTED, align = Paint.Align.RIGHT))
        y = maxOf(y, 205f) + 14f

        fun tableHead(yy: Float): Float {
            val h = pt(8.5f, GOLD, true)
            c.drawText("DESCRIPTION", L, yy, h)
            c.drawText("QTY", 395f, yy, pt(8.5f, GOLD, true, Paint.Align.RIGHT))
            c.drawText("RATE", 475f, yy, pt(8.5f, GOLD, true, Paint.Align.RIGHT))
            c.drawText("AMOUNT", R, yy, pt(8.5f, GOLD, true, Paint.Align.RIGHT))
            c.drawLine(L, yy + 8f, R, yy + 8f, line)
            return yy + 28f
        }
        y = tableHead(y)

        val dp = pt(10.5f, INK)
        var total = 0L
        for (it in items) {
            val lines = wrap(it.description, dp, 310f)
            val h = 14f + lines.size * 14f + 8f
            if (y + h > LIMIT) { y = newPage(); y = tableHead(y) }
            c.drawText(it.category.uppercase(), L, y, pt(7.5f, GOLD, true))
            lines.forEachIndexed { k, s -> c.drawText(s, L, y + 14f + k * 14f, dp) }
            val amt = it.qty * it.rateMinor; total += amt
            val by = y + 14f
            c.drawText(it.qty.toString(), 395f, by, pt(10.5f, INK, align = Paint.Align.RIGHT))
            c.drawText(money(it.rateMinor), 475f, by, pt(10.5f, INK, align = Paint.Align.RIGHT))
            c.drawText(money(amt), R, by, pt(10.5f, INK, align = Paint.Align.RIGHT))
            y += h
            c.drawLine(L, y - 4f, R, y - 4f, line)
        }

        if (y + 50f > LIMIT) y = newPage()
        y += 12f
        c.drawText("TOTAL", 400f, y + 4f, pt(10f, MUTED, true, Paint.Align.RIGHT))
        c.drawText(money(total), R, y + 6f, pt(17f, INK, true, Paint.Align.RIGHT))
        y += 36f

        fun block(title: String, text: String) {
            if (text.isBlank()) return
            val bp = pt(9.5f, INK)
            val ls = wrap(text, bp, R - L)
            if (y + 16f + ls.size * 13f > LIMIT) y = newPage()
            c.drawText(title, L, y, pt(8.5f, GOLD, true)); y += 14f
            ls.forEach { s -> c.drawText(s, L, y, bp); y += 13f }
            y += 10f
        }
        if (!inv.paid) {
            val pay = buildString {
                if (p.get("upi").isNotBlank()) append("UPI: ${p.get("upi")}")
                if (p.get("bank").isNotBlank()) { if (isNotEmpty()) append("\n"); append(p.get("bank")) }
            }
            block("PAYMENT DETAILS", pay)
        }
        block("NOTES", inv.notes)
        block("TERMS", p.get("terms"))

        // Full support footer on the final page
        val m = Paint.Align.CENTER
        c.drawLine(L + 120f, 730f, R - 120f, 730f, line)
        c.drawText(p.get("name"), 297.5f, 750f, pt(11f, INK, true, m))
        c.drawText("Your Vision. Our Creativity.", 297.5f, 763f, pt(8.5f, GOLD, align = m))
        c.drawText("Customer Support: ${p.get("phone")}   |   Email: ${p.get("email")}", 297.5f, 780f, pt(8.5f, INK, align = m))
        c.drawText("Website: ${p.get("website")}", 297.5f, 792f, pt(8.5f, INK, align = m))
        c.drawText("For any queries regarding this invoice, payments or our services, please feel free to contact us.",
            297.5f, 807f, pt(7.5f, MUTED, align = m))
        c.drawText("Thank you for choosing ${p.get("name")}.", 297.5f, 819f, pt(8f, INK, true, m))
        doc.finishPage(page)

        val dir = File(ctx.cacheDir, "pdf").apply { mkdirs() }
        val f = File(dir, fileName(inv.clientName, inv.number))
        FileOutputStream(f).use { doc.writeTo(it) }
        doc.close()
        return f
    }
}
