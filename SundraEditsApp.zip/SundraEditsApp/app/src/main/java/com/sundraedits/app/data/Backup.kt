package com.sundraedits.app.data

import androidx.room.withTransaction
import org.json.JSONArray
import org.json.JSONObject

object Backup {
    class Parsed(val clients: List<Client>, val invoices: List<Invoice>, val items: List<Item>, val prefs: JSONObject)

    suspend fun export(dao: AppDao, p: Prefs): String {
        val o = JSONObject()
        o.put("app", "SundraEdits"); o.put("version", 1)
        val c = JSONArray(); dao.allClients().forEach {
            c.put(JSONObject().put("id", it.id).put("name", it.name).put("phone", it.phone).put("email", it.email))
        }
        val i = JSONArray(); dao.allInvoices().forEach {
            val j = JSONObject().put("id", it.id).put("number", it.number).put("clientId", it.clientId)
                .put("clientName", it.clientName).put("date", it.date).put("paid", it.paid).put("notes", it.notes)
            if (it.paidDate != null) j.put("paidDate", it.paidDate)
            i.put(j)
        }
        val t = JSONArray(); dao.allItems().forEach {
            t.put(JSONObject().put("id", it.id).put("invoiceId", it.invoiceId).put("category", it.category)
                .put("description", it.description).put("qty", it.qty).put("rateMinor", it.rateMinor))
        }
        o.put("clients", c); o.put("invoices", i); o.put("items", t)
        o.put("prefs", JSONObject(p.sp.all))
        return o.toString(1)
    }

    /** Throws with a readable message if the file is not a valid backup. */
    fun parse(s: String): Parsed {
        val o = JSONObject(s)
        require(o.optString("app") == "SundraEdits") { "this is not a Sundra Edits backup" }
        require(o.optInt("version") == 1) { "unsupported backup version" }
        val c = o.getJSONArray("clients"); val i = o.getJSONArray("invoices"); val t = o.getJSONArray("items")
        val clients = (0 until c.length()).map { k -> c.getJSONObject(k).let {
            Client(it.getLong("id"), it.getString("name"), it.optString("phone"), it.optString("email")) } }
        val invoices = (0 until i.length()).map { k -> i.getJSONObject(k).let {
            Invoice(it.getLong("id"), it.getString("number"), it.getLong("clientId"), it.getString("clientName"),
                it.getLong("date"), it.getBoolean("paid"),
                if (it.has("paidDate")) it.getLong("paidDate") else null, it.optString("notes")) } }
        val items = (0 until t.length()).map { k -> t.getJSONObject(k).let {
            Item(it.getLong("id"), it.getLong("invoiceId"), it.getString("category"),
                it.getString("description"), it.getInt("qty"), it.getLong("rateMinor")) } }
        return Parsed(clients, invoices, items, o.optJSONObject("prefs") ?: JSONObject())
    }

    /** Data is fully parsed before anything is touched, so a bad file can never wipe existing data. */
    suspend fun restore(db: AppDb, p: Prefs, parsed: Parsed) {
        val dao = db.dao()
        db.withTransaction {
            dao.clearItems(); dao.clearInvoices(); dao.clearClients()
            dao.putClients(parsed.clients); dao.putInvoices(parsed.invoices); dao.putItems(parsed.items)
        }
        val e = p.sp.edit().clear()
        parsed.prefs.keys().forEach { k ->
            val v = parsed.prefs.get(k)
            if (v is Int) e.putInt(k, v) else e.putString(k, v.toString())
        }
        e.apply()
    }
}
