package com.sundraedits.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.withTransaction
import com.sundraedits.app.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class InvTotal(val inv: Invoice, val total: Long)

class VM(app: Application) : AndroidViewModel(app) {
    val db = AppDb.get(app)
    val dao = db.dao()
    val prefs = Prefs(app)

    val clients = dao.clients().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val rows = combine(dao.invoices(), dao.items()) { inv, its ->
        val m = its.groupBy { x -> x.invoiceId }.mapValues { e -> e.value.sumOf { x -> x.qty * x.rateMinor } }
        inv.map { i -> InvTotal(i, m[i.id] ?: 0L) }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    fun addClient(n: String, ph: String, em: String) {
        viewModelScope.launch { dao.addClient(Client(name = n.trim(), phone = ph.trim(), email = em.trim())) }
    }

    fun setPaid(id: Long, paid: Boolean) {
        viewModelScope.launch { dao.setPaid(id, paid, if (paid) System.currentTimeMillis() else null) }
    }

    fun save(cid: Long, items: List<Item>, paid: Boolean, notes: String, done: (Long) -> Unit) {
        viewModelScope.launch {
            val name = clients.value.firstOrNull { it.id == cid }?.name ?: ""
            val num = prefs.nextNumber()
            val now = System.currentTimeMillis()
            val id = db.withTransaction {
                val i = dao.addInvoice(Invoice(number = num, clientId = cid, clientName = name, date = now,
                    paid = paid, paidDate = if (paid) now else null, notes = notes.trim()))
                dao.addItems(items.map { it.copy(invoiceId = i) })
                i
            }
            done(id)
        }
    }
}
