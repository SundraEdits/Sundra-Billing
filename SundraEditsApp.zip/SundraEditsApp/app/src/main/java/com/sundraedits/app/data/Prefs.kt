package com.sundraedits.app.data

import android.content.Context
import java.util.Calendar

class Prefs(ctx: Context) {
    val sp = ctx.getSharedPreferences("sundra", Context.MODE_PRIVATE)

    companion object {
        val defaults = mapOf(
            "name" to "SUNDRA EDITS", "phone" to "+91 93343 09446",
            "email" to "sundraedits@gmail.com", "website" to "https://sundraedits.in",
            "upi" to "sundraedits@okicici", "bank" to "",
            "terms" to "Thank you for choosing SUNDRA EDITS."
        )
    }

    fun get(k: String): String = sp.getString(k, null) ?: defaults[k] ?: ""
    fun set(k: String, v: String) { sp.edit().putString(k, v).apply() }

    /** Counter only ever goes up, so a number is never reused. */
    @Synchronized fun nextNumber(): String {
        val y = Calendar.getInstance().get(Calendar.YEAR)
        val n = sp.getInt("n_$y", 0) + 1
        sp.edit().putInt("n_$y", n).apply()
        return "SE-$y-" + n.toString().padStart(3, '0')
    }
}
