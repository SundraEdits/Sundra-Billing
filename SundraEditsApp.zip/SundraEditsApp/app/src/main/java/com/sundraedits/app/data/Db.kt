package com.sundraedits.app.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

/** Money is stored in paise (minor units) so totals are always exact. */
@Entity(tableName = "clients")
data class Client(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String, val phone: String = "", val email: String = ""
)

@Entity(tableName = "invoices", indices = [Index(value = ["number"], unique = true)])
data class Invoice(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val number: String, val clientId: Long, val clientName: String,
    val date: Long, val paid: Boolean, val paidDate: Long? = null, val notes: String = ""
)

@Entity(tableName = "items")
data class Item(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val invoiceId: Long, val category: String, val description: String,
    val qty: Int, val rateMinor: Long
)

@Dao
interface AppDao {
    @Query("SELECT * FROM clients ORDER BY name COLLATE NOCASE") fun clients(): Flow<List<Client>>
    @Query("SELECT * FROM invoices ORDER BY id DESC") fun invoices(): Flow<List<Invoice>>
    @Query("SELECT * FROM items") fun items(): Flow<List<Item>>
    @Query("SELECT * FROM items WHERE invoiceId = :id") suspend fun itemsOf(id: Long): List<Item>
    @Insert suspend fun addClient(c: Client): Long
    @Insert suspend fun addInvoice(i: Invoice): Long
    @Insert suspend fun addItems(l: List<Item>)
    @Query("UPDATE invoices SET paid = :p, paidDate = :d WHERE id = :id")
    suspend fun setPaid(id: Long, p: Boolean, d: Long?)

    @Query("SELECT * FROM clients") suspend fun allClients(): List<Client>
    @Query("SELECT * FROM invoices") suspend fun allInvoices(): List<Invoice>
    @Query("SELECT * FROM items") suspend fun allItems(): List<Item>
    @Query("DELETE FROM clients") suspend fun clearClients()
    @Query("DELETE FROM invoices") suspend fun clearInvoices()
    @Query("DELETE FROM items") suspend fun clearItems()
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putClients(l: List<Client>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putInvoices(l: List<Invoice>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putItems(l: List<Item>)
}

@Database(entities = [Client::class, Invoice::class, Item::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): AppDao
    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(c: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, AppDb::class.java, "sundra.db")
                .build().also { inst = it }
        }
    }
}
